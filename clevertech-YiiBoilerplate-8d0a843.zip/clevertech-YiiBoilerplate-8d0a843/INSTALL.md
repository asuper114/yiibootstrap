h1. Boilerplate project installation instructions

You should insert all prequisites for your project
along with installation instructions in here.
Do not forget to add description of project to @README.md@ document!