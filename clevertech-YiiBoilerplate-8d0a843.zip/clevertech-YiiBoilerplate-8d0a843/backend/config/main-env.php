<?php
/**
 * main-env.php
 *
 * @author: antonio ramirez <antonio@clevertech.biz>
 * Date: 7/22/12
 * Time: 6:26 PM
 *
 * Once used, the runpostdeploy command, this file will be filled with the configuration details of the environment
 * specified in the command and will be merged with the main.php configuration file.
 */
return array();